# Readme.md

I have implemented all parts regarding the Houdini Plugins.

Below is the capture of the custom L-System node that I have integrated into Houdini

![](E:\repos\Course-Projects\CIS6600-MayaPlugins\CIS6600-HW04\Proj-Img\Clipboard%20Image.jpg)

You can watch the video here at Houdini_demo.mp4 in the project folder